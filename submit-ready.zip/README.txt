Ceci est un fichier README généré automatiquement.
