// ThemeForest Validator Pro - Validation Criteria
// Critères de validation enrichis basés sur les standards ThemeForest 2025

const VALIDATION_CRITERIA = {
    structure: {
        name: "Structure & Architecture",
        weight: 18,
        icon: "🏗️",
        color: "blue",
        checks: [
            { 
                name: "Fichier index.html principal", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Un fichier index.html doit être présent à la racine du template",
                fix: "Créez un fichier index.html à la racine de votre template"
            },
            { 
                name: "Dossier assets/ organisé", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Structure organisée avec dossiers css/, js/, img/, fonts/",
                fix: "Organisez vos ressources dans un dossier assets/ avec sous-dossiers"
            },
            { 
                name: "Documentation README complète", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "README.md avec instructions d'installation et personnalisation",
                fix: "Créez un fichier README.md détaillé avec toutes les instructions"
            },
            { 
                name: "Structure responsive cohérente", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Organisation logique des breakpoints et media queries",
                fix: "Organisez vos media queries de manière cohérente (mobile-first)"
            },
            { 
                name: "Hiérarchie logique des dossiers", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Nomenclature claire et structure intuitive",
                fix: "Renommez vos dossiers avec une nomenclature claire et logique"
            },
            { 
                name: "Fichiers sources PSD/Figma", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Fichiers de design source pour personnalisation avancée",
                fix: "Incluez les fichiers sources de design (PSD, Figma, Sketch)"
            },
            { 
                name: "Guide d'installation détaillé", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Instructions pas-à-pas pour l'installation et configuration",
                fix: "Rédigez un guide d'installation étape par étape"
            },
            { 
                name: "Changelog maintenu", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Historique des versions et modifications",
                fix: "Créez un fichier CHANGELOG.md pour suivre les versions"
            },
            { 
                name: "Licence légale incluse", 
                required: true, 
                severity: "medium", 
                points: 5,
                description: "Fichier LICENSE avec droits d'usage clairement définis",
                fix: "Ajoutez un fichier LICENSE avec les termes d'utilisation"
            },
            { 
                name: "Fichier package.json/bower.json", 
                required: false, 
                severity: "medium", 
                points: 7,
                description: "Gestion des dépendances avec gestionnaire de paquets",
                fix: "Créez un package.json pour gérer les dépendances"
            },
            // Nouveaux critères de structure de dossier
            { 
                name: "Dossier /Template/", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Le dossier /Template/ doit contenir tous les fichiers finaux (HTML, CSS, JS ou thème WordPress).",
                fix: "Assurez-vous que tous les fichiers finaux sont dans le dossier /Template/"
            },
            { 
                name: "Dossier /Documentation/", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Le dossier /Documentation/ doit contenir un guide utilisateur en anglais (HTML ou PDF).",
                fix: "Créez un dossier /Documentation/ avec un guide utilisateur en anglais"
            },
            { 
                name: "Dossier /Screenshots/", 
                required: true, 
                severity: "critical", 
                points: 10,
                description: "Le dossier /Screenshots/ doit inclure main-preview.jpg (590x300px min) + captures additionnelles.",
                fix: "Ajoutez main-preview.jpg (590x300px min) et des captures additionnelles dans /Screenshots/"
            },
            { 
                name: "Dossier /Licenses/", 
                required: true, 
                severity: "critical", 
                points: 10,
                description: "Le dossier /Licenses/ doit contenir les licences des polices, bibliothèques, plugins, etc.",
                fix: "Incluez les licences des polices, bibliothèques, plugins, etc. dans le dossier /Licenses/"
            },
            { 
                name: "Fichier changelog.txt", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Le fichier changelog.txt doit contenir le journal des modifications.",
                fix: "Créez un fichier changelog.txt avec l'historique des modifications"
            },
            { 
                name: "Fichier readme.txt", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Le fichier readme.txt doit contenir les instructions de base pour l’utilisateur.",
                fix: "Créez un fichier readme.txt avec les instructions de base"
            }
        ]
    },

    htmlQuality: {
        name: "Qualité HTML",
        weight: 16,
        icon: "📝",
        color: "orange",
        checks: [
            { 
                name: "HTML5 sémantique valide", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Utilisation correcte des balises sémantiques HTML5",
                fix: "Utilisez les balises sémantiques HTML5 (header, nav, main, section, article, aside, footer)"
            },
            { 
                name: "Structure DOCTYPE correcte", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "DOCTYPE HTML5 présent et correct",
                fix: "Ajoutez <!DOCTYPE html> au début de vos fichiers HTML"
            },
            { 
                name: "Meta tags complets", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Meta viewport, description, keywords, author présents",
                fix: "Ajoutez tous les meta tags essentiels (viewport, description, keywords, author)"
            },
            { 
                name: "Accessibilité ARIA", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Attributs ARIA pour améliorer l'accessibilité",
                fix: "Ajoutez les attributs ARIA appropriés (aria-label, aria-describedby, etc.)"
            },
            { 
                name: "Alt text sur toutes images", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Attributs alt descriptifs sur toutes les images",
                fix: "Ajoutez des attributs alt descriptifs à toutes vos images"
            },
            { 
                name: "Structure heading hiérarchique", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Hiérarchie logique des titres H1-H6",
                fix: "Organisez vos titres de manière hiérarchique (H1 unique, puis H2, H3, etc.)"
            },
            { 
                name: "Formulaires accessibles", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Labels associés aux champs de formulaire",
                fix: "Associez des labels à tous vos champs de formulaire"
            },
            { 
                name: "Navigation clavier", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Navigation possible au clavier avec tabindex",
                fix: "Assurez-vous que tous les éléments interactifs sont accessibles au clavier"
            },
            { 
                name: "Validation W3C", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Code HTML valide selon les standards W3C",
                fix: "Validez votre HTML sur validator.w3.org et corrigez les erreurs"
            },
            { 
                name: "Open Graph meta tags", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Meta tags pour partage sur réseaux sociaux",
                fix: "Ajoutez les meta tags Open Graph pour Facebook/LinkedIn"
            },
            { 
                name: "Twitter Card meta tags", 
                required: false, 
                severity: "medium", 
                points: 6,
                description: "Meta tags pour partage Twitter optimisé",
                fix: "Ajoutez les meta tags Twitter Card pour un partage optimisé"
            },
            { 
                name: "Données structurées Schema.org", 
                required: false, 
                severity: "medium", 
                points: 10,
                description: "Balisage JSON-LD pour les moteurs de recherche",
                fix: "Ajoutez des données structurées Schema.org en JSON-LD"
            },
            { 
                name: "Favicon complet", 
                required: true, 
                severity: "medium", 
                points: 6,
                description: "Favicon avec toutes les tailles nécessaires",
                fix: "Incluez un favicon complet avec toutes les tailles (16x16, 32x32, etc.)"
            },
            // Nouveaux critères HTML
            { 
                name: "Pas de CSS/JS inline excessif", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Évitez le CSS et JavaScript inline excessif pour une meilleure maintenabilité.",
                fix: "Déplacez le CSS et JavaScript inline vers des fichiers externes ou des balises <style>/<script> dans le <head> ou avant </body>."
            }
        ]
    },

    cssQuality: {
        name: "Qualité CSS",
        weight: 16,
        icon: "🎨",
        color: "blue",
        checks: [
            { 
                name: "CSS3 moderne organisé", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "CSS bien structuré avec commentaires et organisation logique",
                fix: "Organisez votre CSS avec des commentaires et une structure logique"
            },
            { 
                name: "Variables CSS définies", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Utilisation de custom properties CSS pour la cohérence",
                fix: "Définissez des variables CSS (:root) pour les couleurs, tailles, etc."
            },
            { 
                name: "Mobile-first responsive", 
                required: true, 
                severity: "critical", 
                points: 18,
                description: "Approche mobile-first avec media queries appropriées",
                fix: "Adoptez une approche mobile-first avec media queries progressives"
            },
            { 
                name: "Flexbox/Grid moderne", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Layouts modernes avec Flexbox et CSS Grid",
                fix: "Utilisez Flexbox et CSS Grid pour vos layouts modernes"
            },
            { 
                name: "Animations optimisées", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Animations fluides avec transform et opacity",
                fix: "Optimisez vos animations en utilisant transform et opacity"
            },
            { 
                name: "Print styles inclus", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Feuille de style pour l'impression",
                fix: "Ajoutez des styles d'impression avec @media print"
            },
            { 
                name: "Dark mode support", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Support du mode sombre avec prefers-color-scheme",
                fix: "Implémentez le support du mode sombre avec prefers-color-scheme"
            },
            { 
                name: "CSS minifié pour prod", 
                required: false, 
                severity: "medium", 
                points: 7,
                description: "Version minifiée pour la production",
                fix: "Fournissez une version minifiée de votre CSS pour la production"
            },
            { 
                name: "Compatibilité navigateurs", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Support des navigateurs modernes avec fallbacks",
                fix: "Testez et ajoutez des fallbacks pour la compatibilité navigateurs"
            },
            { 
                name: "CSS critique inline", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "CSS critique inline pour améliorer le LCP",
                fix: "Intégrez le CSS critique inline pour améliorer les performances"
            },
            { 
                name: "Préfixes vendeurs appropriés", 
                required: true, 
                severity: "medium", 
                points: 7,
                description: "Préfixes -webkit, -moz pour compatibilité",
                fix: "Ajoutez les préfixes vendeurs nécessaires pour la compatibilité"
            },
            { 
                name: "Unités relatives utilisées", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Utilisation de rem, em, %, vw, vh pour la flexibilité",
                fix: "Utilisez des unités relatives (rem, em, %) plutôt que des pixels fixes"
            },
            // Nouveaux critères CSS
            { 
                name: "CSS structuré, préfixes auto-générés", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Le CSS doit être bien structuré et les préfixes vendeurs doivent être auto-générés (ex: Autoprefixer).",
                fix: "Utilisez un outil comme Autoprefixer pour gérer les préfixes vendeurs et organisez votre CSS."
            },
            { 
                name: "Convention de nommage claire (BEM recommandé)", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Adoptez une convention de nommage claire pour vos classes CSS (ex: BEM).",
                fix: "Implémentez une convention de nommage comme BEM pour vos classes CSS."
            },
            { 
                name: "SCSS/SASS organisé si utilisé", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Si vous utilisez SCSS/SASS, assurez-vous que votre code est bien organisé en modules.",
                fix: "Organisez vos fichiers SCSS/SASS en modules logiques pour une meilleure maintenabilité."
            }
        ]
    },

    jsQuality: {
        name: "Qualité JavaScript",
        weight: 15,
        icon: "⚡",
        color: "yellow",
        checks: [
            { 
                name: "ES6+ moderne", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Syntaxe JavaScript moderne (const, let, arrow functions)",
                fix: "Utilisez la syntaxe ES6+ moderne (const, let, arrow functions, etc.)"
            },
            { 
                name: "Code modulaire organisé", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Code organisé en modules réutilisables",
                fix: "Organisez votre code en modules réutilisables et maintenables"
            },
            { 
                name: "Gestion d'erreurs complète", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Try-catch appropriés et gestion des erreurs",
                fix: "Implémentez une gestion d'erreurs robuste avec try-catch"
            },
            { 
                name: "Performance optimisée", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Code optimisé sans fuites mémoire",
                fix: "Optimisez votre code pour éviter les fuites mémoire et améliorer les performances"
            },
            { 
                name: "Pas de console.log", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Suppression des console.log en production",
                fix: "Supprimez tous les console.log de votre code de production"
            },
            { 
                name: "Event listeners propres", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Ajout/suppression correcte des event listeners",
                fix: "Gérez correctement l'ajout et la suppression des event listeners"
            },
            { 
                name: "Minification pour prod", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Version minifiée pour la production",
                fix: "Fournissez une version minifiée de votre JavaScript pour la production"
            },
            { 
                name: "Documentation JSDoc", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Documentation des fonctions avec JSDoc",
                fix: "Documentez vos fonctions avec la syntaxe JSDoc"
            },
            { 
                name: "Async/Await moderne", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Gestion asynchrone moderne avec async/await",
                fix: "Utilisez async/await plutôt que les callbacks ou .then()"
            },
            { 
                name: "Validation des entrées", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Validation et sanitisation des données utilisateur",
                fix: "Validez et sanitisez toutes les entrées utilisateur"
            },
            { 
                name: "Polyfills pour compatibilité", 
                required: false, 
                severity: "medium", 
                points: 6,
                description: "Polyfills pour navigateurs plus anciens",
                fix: "Incluez les polyfills nécessaires pour assurer la compatibilité avec les navigateurs plus anciens"
            },
            // Nouveaux critères JavaScript
            { 
                name: "Aucune erreur dans la console navigateur", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Le code JavaScript ne doit générer aucune erreur dans la console du navigateur.",
                fix: "Corrigez toutes les erreurs JavaScript affichées dans la console du navigateur."
            },
            { 
                name: "JS modulaire, sans fonctions globales", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Organisez votre JavaScript en modules pour éviter les fonctions globales et les conflits.",
                fix: "Refactorisez votre code JavaScript en utilisant des modules (ESM) ou des IIFE pour éviter la portée globale."
            }
        ]
    },

    designUIUX: {
        name: "Design et UI/UX",
        weight: 12,
        icon: "🎨",
        color: "purple",
        checks: [
            { 
                name: "Design cohérent", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Le design doit être cohérent en termes d'espacement, d'alignement et de styles.",
                fix: "Assurez une cohérence visuelle sur l'ensemble du template (espacement, alignement, typographie, couleurs)."
            },
            { 
                name: "Typographie lisible", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "La typographie doit être lisible et adaptée au contenu (Google Fonts ou équivalent libre).",
                fix: "Choisissez des polices lisibles et assurez un contraste suffisant entre le texte et l'arrière-plan."
            },
            { 
                name: "Hiérarchie visuelle claire", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "La hiérarchie visuelle doit être claire pour guider l'utilisateur.",
                fix: "Utilisez la taille, la couleur et le poids des éléments pour créer une hiérarchie visuelle claire."
            },
            { 
                name: "Aucune section cassée visuellement", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Aucune section du design ne doit être cassée ou mal affichée.",
                fix: "Vérifiez l'affichage de toutes les sections sur différentes résolutions et corrigez les problèmes visuels."
            },
            { 
                name: "Icônes vectorielles (SVG ou librairie)", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Utilisez des icônes vectorielles (SVG) ou une librairie d'icônes pour une meilleure qualité.",
                fix: "Remplacez les icônes bitmap par des SVG ou utilisez une librairie d'icônes (Font Awesome, Material Icons)."
            },
            { 
                name: "Images libres de droits ou placeholders", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Toutes les images doivent être libres de droits ou des placeholders.",
                fix: "Assurez-vous que toutes les images utilisées sont libres de droits ou utilisez des placeholders appropriés."
            },
            { 
                name: "Transitions CSS/JS douces et propres", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Les transitions et animations doivent être douces et professionnelles.",
                fix: "Optimisez vos transitions CSS et animations JavaScript pour une expérience utilisateur fluide."
            },
            // Nouveaux critères Design & UX avancés
            { 
                name: "Grille et alignement maîtrisés", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Utilisation d'une grille cohérente et alignement précis des éléments.",
                fix: "Implémentez une grille de base cohérente et alignez tous les éléments selon cette grille."
            },
            { 
                name: "Espacement rythmé et cohérent", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Espacement vertical et horizontal suivant un rythme cohérent.",
                fix: "Définissez un système d'espacement basé sur des multiples (ex: 8px, 16px, 24px, 32px)."
            },
            { 
                name: "Palette de couleurs harmonieuse", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Palette de couleurs limitée et harmonieuse avec contrastes appropriés.",
                fix: "Limitez votre palette à 3-5 couleurs principales et assurez des contrastes suffisants."
            },
            { 
                name: "Lisibilité et équilibre visuel", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Équilibre visuel entre les éléments et lisibilité optimale du contenu.",
                fix: "Équilibrez la densité visuelle et assurez une lisibilité optimale (taille, contraste, espacement)."
            },
            { 
                name: "Cohérence des composants UI", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Cohérence dans le style des boutons, formulaires, cartes et autres composants.",
                fix: "Standardisez le style de tous vos composants UI (boutons, inputs, cartes, etc.)."
            },
            { 
                name: "Micro-interactions et feedback", 
                required: false, 
                severity: "low", 
                points: 6,
                description: "Micro-interactions appropriées pour améliorer l'expérience utilisateur.",
                fix: "Ajoutez des micro-interactions subtiles (hover, focus, loading) pour améliorer l'UX."
            }
        ]
    },

    performance: {
        name: "Performance",
        weight: 12,
        icon: "🚀",
        color: "green",
        checks: [
            { 
                name: "Images optimisées WebP", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Images converties au format WebP avec fallback JPEG/PNG",
                fix: "Convertissez vos images au format WebP avec fallback JPEG/PNG"
            },
            { 
                name: "Lazy loading implémenté", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Lazy loading pour les images et ressources non critiques",
                fix: "Implémentez le lazy loading pour les images et ressources non critiques"
            },
            { 
                name: "CSS critique inline", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "CSS critique inline pour améliorer le LCP",
                fix: "Intégrez le CSS critique inline dans le HTML"
            },
            { 
                name: "Ressources defer/async", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Scripts chargés avec defer ou async pour non-blocage",
                fix: "Chargez vos scripts avec defer ou async pour ne pas bloquer le rendu"
            },
            { 
                name: "Taille totale < 5MB", 
                required: false, 
                severity: "medium", 
                points: 10,
                description: "Taille totale du template inférieure à 5MB",
                fix: "Optimisez la taille de votre template pour qu'elle soit inférieure à 5MB"
            },
            { 
                name: "Fonts optimisées", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Polices optimisées (formats WOFF2, subsetting)",
                fix: "Optimisez vos polices (formats WOFF2, subsetting) et préchargez-les"
            },
            { 
                name: "Cache headers", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "En-têtes de cache appropriés pour les ressources statiques",
                fix: "Configurez des en-têtes de cache appropriés pour vos ressources statiques"
            },
            { 
                name: "Core Web Vitals optimisés", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Optimisation pour LCP, FID, CLS",
                fix: "Optimisez votre template pour les Core Web Vitals (LCP, FID, CLS)"
            },
            { 
                name: "Compression Gzip/Brotli", 
                required: false, 
                severity: "medium", 
                points: 7,
                description: "Compression des ressources côté serveur",
                fix: "Assurez-vous que votre serveur utilise la compression Gzip/Brotli"
            },
            { 
                name: "Sprites CSS/SVG", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Utilisation de sprites pour les petites images/icônes",
                fix: "Utilisez des sprites CSS ou SVG pour regrouper les petites images/icônes"
            },
            // Nouveaux critères de performance
            { 
                name: "Score Lighthouse > 90", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Le template doit obtenir un score Lighthouse supérieur à 90 pour Performance, SEO et Accessibilité.",
                fix: "Effectuez un audit Lighthouse et corrigez les problèmes pour atteindre un score > 90 dans les catégories clés."
            },
            { 
                name: "Score GTMetrix : A ou B", 
                required: false, 
                severity: "high", 
                points: 15,
                description: "Le template devrait obtenir un score GTMetrix de A ou B.",
                fix: "Optimisez votre template pour obtenir un score GTMetrix de A ou B."
            },
            { 
                name: "CSS/JS minifiés", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Tous les fichiers CSS et JavaScript doivent être minifiés pour la production.",
                fix: "Minifiez vos fichiers CSS et JavaScript avant la soumission."
            },
            { 
                name: "Images optimisées (TinyPNG, ImageOptim)", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Toutes les images doivent être optimisées pour le web (ex: TinyPNG, ImageOptim).",
                fix: "Optimisez toutes vos images en utilisant des outils comme TinyPNG ou ImageOptim."
            }
        ]
    },

    accessibility: {
        name: "Accessibilité",
        weight: 10,
        icon: "♿",
        color: "green",
        checks: [
            { 
                name: "WCAG 2.1 AA", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Conformité aux directives WCAG 2.1 niveau AA",
                fix: "Assurez la conformité de votre template aux directives WCAG 2.1 niveau AA"
            },
            { 
                name: "Navigation clavier", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Tous les éléments interactifs accessibles au clavier",
                fix: "Vérifiez que tous les éléments interactifs sont navigables au clavier (tabindex, focus)"
            },
            { 
                name: "Contraste des couleurs", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Contraste suffisant entre texte et arrière-plan",
                fix: "Assurez un contraste de couleurs suffisant pour le texte et les éléments graphiques"
            },
            { 
                name: "Lecteurs d'écran", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Compatibilité avec les lecteurs d'écran (ARIA, sémantique)",
                fix: "Testez votre template avec des lecteurs d'écran et utilisez les attributs ARIA appropriés"
            },
            { 
                name: "Taille de police ajustable", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Possibilité d'ajuster la taille de police sans casser le layout",
                fix: "Utilisez des unités relatives (rem, em) pour les tailles de police"
            },
            { 
                name: "Focus visible", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Indicateurs de focus clairs pour la navigation clavier",
                fix: "Assurez que les indicateurs de focus sont clairement visibles pour les utilisateurs au clavier"
            }
        ]
    },

    seo: {
        name: "SEO",
        weight: 7,
        icon: "🔍",
        color: "red",
        checks: [
            { 
                name: "Meta tags essentiels", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Meta title, description, keywords présents et pertinents",
                fix: "Renseignez des meta title, description, keywords pertinents pour chaque page"
            },
            { 
                name: "Structure heading sémantique", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Utilisation correcte des balises H1-H6 pour la structure du contenu",
                fix: "Organisez vos titres de manière sémantique (H1 unique par page, puis H2, H3, etc.)"
            },
            { 
                name: "URLs propres et sémantiques", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "URLs lisibles et descriptives",
                fix: "Utilisez des URLs propres et sémantiques (ex: /about-us au lieu de /page?id=1)"
            },
            { 
                name: "Images optimisées pour le SEO", 
                required: true, 
                severity: "medium", 
                points: 8,
                description: "Attributs alt et titres descriptifs pour les images",
                fix: "Ajoutez des attributs alt et titres descriptifs à toutes vos images"
            },
            { 
                name: "Données structurées Schema.org", 
                required: false, 
                severity: "medium", 
                points: 10,
                description: "Balisage JSON-LD pour les moteurs de recherche",
                fix: "Ajoutez des données structurées Schema.org en JSON-LD pour améliorer la visibilité"
            },
            { 
                name: "Fichier robots.txt", 
                required: false, 
                severity: "low", 
                points: 3,
                description: "Fichier robots.txt pour contrôler l'indexation",
                fix: "Créez un fichier robots.txt pour guider les robots des moteurs de recherche"
            },
            { 
                name: "Fichier sitemap.xml", 
                required: false, 
                severity: "low", 
                points: 3,
                description: "Fichier sitemap.xml pour faciliter l'exploration",
                fix: "Créez un fichier sitemap.xml pour aider les moteurs de recherche à explorer votre site"
            }
        ]
    },

    security: {
        name: "Sécurité",
        weight: 8,
        icon: "🔒",
        color: "darkblue",
        checks: [
            { 
                name: "HTTPS obligatoire", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Toutes les ressources doivent être servies en HTTPS",
                fix: "Assurez-vous que toutes les ressources sont servies en HTTPS"
            },
            { 
                name: "Protection XSS", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Protection contre les attaques Cross-Site Scripting",
                fix: "Protégez-vous contre les vulnérabilités XSS en validant et échappant les entrées utilisateur"
            },
            { 
                name: "Validation des entrées", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Validation côté client et serveur des données utilisateur",
                fix: "Validez toutes les entrées utilisateur pour prévenir les injections et autres attaques"
            },
            { 
                name: "Protection CSRF", 
                required: false, 
                severity: "medium", 
                points: 10,
                description: "Protection contre les attaques Cross-Site Request Forgery",
                fix: "Implémentez une protection CSRF pour vos formulaires (si applicable)"
            },
            { 
                name: "Mots de passe sécurisés", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Si le template inclut des formulaires d'authentification, assurez la sécurité des mots de passe",
                fix: "Utilisez des pratiques de hachage de mots de passe robustes (ex: bcrypt) et des politiques de mots de passe forts"
            }
        ]
    },

    browserCompatibility: {
        name: "Compatibilité Navigateurs",
        weight: 6,
        icon: "🌐",
        color: "cyan",
        checks: [
            { 
                name: "Chrome/Edge récents", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Compatibilité avec les dernières versions de Chrome et Edge",
                fix: "Testez et assurez la compatibilité avec Chrome/Edge récents"
            },
            { 
                name: "Firefox récent", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Compatibilité avec la dernière version de Firefox",
                fix: "Testez et assurez la compatibilité avec Firefox récent"
            },
            { 
                name: "Safari desktop et mobile", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Compatibilité avec Safari sur desktop et mobile",
                fix: "Testez et assurez la compatibilité avec Safari desktop et mobile"
            },
            { 
                name: "Dégradation gracieuse", 
                required: false, 
                severity: "medium", 
                points: 10,
                description: "Fonctionnalités avancées avec dégradation gracieuse pour navigateurs plus anciens",
                fix: "Implémentez une dégradation gracieuse pour les fonctionnalités avancées"
            },
            // Nouveaux critères de compatibilité
            { 
                name: "Aucune console.log(), alert() ou contenu débogage", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Assurez-vous qu'il n'y a pas de console.log(), alert() ou autre contenu de débogage dans le code final.",
                fix: "Supprimez tous les appels à console.log(), alert() et tout contenu de débogage avant la soumission."
            }
        ]
    },

    codeQuality: {
        name: "Qualité du Code",
        weight: 6,
        icon: "💎",
        color: "gray",
        checks: [
            { 
                name: "Formatage cohérent", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Indentation, espacement, et conventions de formatage cohérentes",
                fix: "Formatez votre code avec une indentation cohérente (Prettier, ESLint)"
            },
            { 
                name: "Commentaires pertinents", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Commentaires pour expliquer la logique complexe",
                fix: "Ajoutez des commentaires pour expliquer la logique complexe"
            },
            { 
                name: "Nommage cohérent", 
                required: true, 
                severity: "high", 
                points: 12,
                description: "Convention de nommage claire et cohérente (variables, fonctions, classes)",
                fix: "Adoptez une convention de nommage cohérente (camelCase, snake_case, PascalCase)"
            },
            { 
                name: "DRY principle", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "Éviter la duplication de code (Don't Repeat Yourself)",
                fix: "Appliquez le principe DRY (Don't Repeat Yourself) pour éviter la duplication de code"
            },
            { 
                name: "Validation des outils", 
                required: false, 
                severity: "medium", 
                points: 5,
                description: "Passage des linters et validateurs (ESLint, Stylelint)",
                fix: "Utilisez des linters et validateurs pour vérifier votre code (ESLint, Stylelint)"
            }
        ]
    },

    documentation: {
        name: "Documentation",
        weight: 10,
        icon: "📑",
        color: "brown",
        checks: [
            { 
                name: "Rédigée en anglais clair", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "La documentation doit être rédigée en anglais clair et compréhensible.",
                fix: "Assurez-vous que toute la documentation est en anglais et facile à comprendre."
            },
            { 
                name: "Explication installation étape par étape", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "La documentation doit inclure une explication étape par étape de l'installation.",
                fix: "Ajoutez une section d'installation détaillée dans votre documentation."
            },
            { 
                name: "Liste des dépendances", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "La documentation doit lister toutes les dépendances (Bootstrap, jQuery, etc.).",
                fix: "Incluez une liste complète de toutes les dépendances utilisées dans votre documentation."
            },
            { 
                name: "Explication structure des fichiers", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "La documentation doit expliquer la structure des fichiers du template.",
                fix: "Décrivez clairement la structure de vos fichiers et dossiers dans la documentation."
            },
            { 
                name: "Instructions de personnalisation", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "La documentation doit fournir des instructions claires pour la personnalisation (menus, couleurs...).",
                fix: "Ajoutez des instructions détaillées sur la façon de personnaliser le template."
            },
            { 
                name: "FAQ ou section support", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Une section FAQ ou support est recommandée dans la documentation.",
                fix: "Envisagez d'ajouter une section FAQ ou support pour aider les utilisateurs."
            }
        ]
    },

    demoPreview: {
        name: "Démo (preview)",
        weight: 8,
        icon: "🔍",
        color: "teal",
        checks: [
            { 
                name: "Lien de démo propre et complet", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Le lien de démo doit être propre, complet et fonctionnel.",
                fix: "Assurez-vous que votre démo est accessible, complète et sans erreurs."
            },
            { 
                name: "Aucun contenu mort ou lien 404", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "La démo ne doit contenir aucun contenu mort ou lien 404.",
                fix: "Vérifiez tous les liens et le contenu de votre démo pour éviter les erreurs 404 ou le contenu manquant."
            },
            { 
                name: "Navigation claire entre les pages", 
                required: true, 
                severity: "high", 
                points: 10,
                description: "La navigation entre les pages de démonstration doit être claire et intuitive.",
                fix: "Assurez une navigation fluide et logique entre toutes les pages de votre démo."
            },
            { 
                name: "Version responsive testée", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "La version responsive de la démo doit être testée sur mobile/tablette.",
                fix: "Testez la réactivité de votre démo sur différents appareils et résolutions."
            },
            { 
                name: "Aucun tracking, pub, popup invasif", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "La démo ne doit contenir aucun tracking, publicité ou popup invasif.",
                fix: "Supprimez tout code de tracking, publicité ou popup invasif de votre démo."
            }
        ]
    },

    requiredFiles: {
        name: "Fichiers spécifiques requis",
        weight: 10,
        icon: "📝",
        color: "indigo",
        checks: [
            { 
                name: "main-preview.jpg (min. 590x300px)", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Le fichier main-preview.jpg est requis (min. 590x300px, recommandé 900x600).",
                fix: "Fournissez un fichier main-preview.jpg respectant les dimensions requises."
            },
            { 
                name: "screenshot.jpg/png", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Le fichier screenshot.jpg/png est requis (vue d'ensemble du template).",
                fix: "Fournissez un fichier screenshot.jpg ou .png montrant une vue d'ensemble du template."
            },
            { 
                name: "readme.txt", 
                required: true, 
                severity: "critical", 
                points: 10,
                description: "Le fichier readme.txt est requis (résumé technique).",
                fix: "Fournissez un fichier readme.txt avec un résumé technique de votre template."
            },
            { 
                name: "documentation/index.html", 
                required: true, 
                severity: "critical", 
                points: 15,
                description: "Le fichier documentation/index.html est requis (guide utilisateur).",
                fix: "Fournissez un fichier documentation/index.html avec le guide utilisateur."
            },
            { 
                name: "changelog.txt", 
                required: false, 
                severity: "medium", 
                points: 8,
                description: "Le fichier changelog.txt est recommandé (historique des versions).",
                fix: "Envisagez d'inclure un fichier changelog.txt pour l'historique des versions."
            },
            { 
                name: "/Licenses/", 
                required: true, 
                severity: "critical", 
                points: 10,
                description: "Le dossier /Licenses/ est requis (détail des éléments tiers).",
                fix: "Incluez le dossier /Licenses/ avec les détails des licences des éléments tiers."
            }
        ]
    },

    thirdPartyResources: {
        name: "Ressources tierces",
        weight: 7,
        icon: "📎",
        color: "pink",
        checks: [
            { 
                name: "Polices libres", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Utilisez uniquement des polices libres (Google Fonts, Font Squirrel, etc.).",
                fix: "Assurez-vous que toutes les polices utilisées sont libres de droits ou sous licence appropriée."
            },
            { 
                name: "Plugins sous licence libre", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Utilisez uniquement des plugins sous licence libre (GPL, MIT).",
                fix: "Vérifiez les licences de tous les plugins et assurez-vous qu'ils sont sous licence libre."
            },
            { 
                name: "Attribution mentionnée dans la doc", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "L'attribution des ressources tierces doit être mentionnée dans la documentation.",
                fix: "Ajoutez une section dans votre documentation pour attribuer toutes les ressources tierces utilisées."
            },
            { 
                name: "Aucun contenu soumis à copyright", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Le template ne doit contenir aucun contenu soumis à copyright sans autorisation.",
                fix: "Supprimez tout contenu soumis à copyright ou obtenez les autorisations nécessaires."
            }
        ]
    },

    manualTests: {
        name: "Tests manuels à effectuer",
        weight: 5,
        icon: "🧪",
        color: "lime",
        checks: [
            { 
                name: "Validation HTML via W3C Validator", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Effectuez une validation HTML via le W3C Validator.",
                fix: "Utilisez https://validator.w3.org/ pour valider votre HTML."
            },
            { 
                name: "Test responsive via Chrome DevTools ou BrowserStack", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Effectuez des tests responsives via Chrome DevTools ou BrowserStack.",
                fix: "Testez la réactivité de votre template sur différents appareils en utilisant les outils de développement ou BrowserStack."
            },
            { 
                name: "Audit SEO/Performance via Lighthouse", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Effectuez un audit SEO/Performance via Google Lighthouse.",
                fix: "Utilisez Google Lighthouse pour auditer les performances et le SEO de votre template."
            },
            { 
                name: "Contrôle console navigateur (aucune erreur)", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Vérifiez la console du navigateur pour s'assurer qu'il n'y a aucune erreur.",
                fix: "Ouvrez la console de votre navigateur et corrigez toutes les erreurs JavaScript."
            },
            { 
                name: "Optimisation des images avec TinyPNG ou ImageOptim", 
                required: false, 
                severity: "low", 
                points: 5,
                description: "Optimisez vos images avec des outils comme TinyPNG ou ImageOptim.",
                fix: "Passez vos images dans TinyPNG ou ImageOptim pour réduire leur taille."
            }
        ]
    },

    wordpressSpecific: {
        name: "WordPress (si applicable)",
        weight: 10,
        icon: "WP",
        color: "darkgreen",
        checks: [
            { 
                name: "Respect des standards WordPress officiels", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "Le thème/plugin doit respecter les standards de codage WordPress.",
                fix: "Consultez le Codex WordPress et assurez-vous de respecter les standards de codage."
            },
            { 
                name: "Compatible avec Gutenberg", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Le thème doit être compatible avec l'éditeur de blocs Gutenberg.",
                fix: "Testez et assurez la compatibilité de votre thème avec Gutenberg."
            },
            { 
                name: "Utilisation de wp_enqueue_* pour CSS/JS", 
                required: true, 
                severity: "high", 
                points: 15,
                description: "Utilisez wp_enqueue_style() et wp_enqueue_script() pour charger les CSS et JS.",
                fix: "Chargez vos feuilles de style et scripts via wp_enqueue_style() et wp_enqueue_script()."
            },
            { 
                name: "Fichier .pot de traduction inclus", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Un fichier .pot (Portable Object Template) doit être inclus pour la traduction.",
                fix: "Générez et incluez un fichier .pot pour permettre la traduction de votre thème/plugin."
            },
            { 
                name: "Textdomain correct", 
                required: true, 
                severity: "medium", 
                points: 10,
                description: "Le textdomain doit être correctement défini et utilisé pour l'internationalisation.",
                fix: "Définissez et utilisez un textdomain unique pour toutes les chaînes traduisibles."
            },
            { 
                name: "Aucun plugin premium non autorisé", 
                required: true, 
                severity: "critical", 
                points: 20,
                description: "N'incluez aucun plugin premium sans licence ou autorisation appropriée.",
                fix: "Supprimez les plugins premium non autorisés ou assurez-vous d'avoir les licences nécessaires."
            }
        ]
    }
};


