// ThemeForest Validator Pro - Core Validation Engine
// Moteur principal de validation avec analyse approfondie

const AutoFixPro = require(\'./autofix-pro\');
const DocBuilder = require(\'./doc-builder\');
const PreviewSnapshot = require(\'./preview-snapshot\');
const AIAssistant = require(\'./ai-assistant\');
const ReviewerIntelligence = require(\'./reviewer-intelligence\');
const LiveReviewer = require(\'./live-reviewer\');
const HistoryProgress = require(\'./history-progress\');

class ThemeForestValidator {
    constructor() {
        this.analysisResults = {
            fileName: \'\',
            fileSize: 0,
            issues: [],
            successes: [],
            fileAnalysis: {},
            categoryScores: {},
            totalScore: 0,
            totalChecks: 0,
            passedChecks: 0,
            analysisTime: 0,
            recommendations: []
        };
        
        this.fileStructure = {
            htmlFiles: [],
            cssFiles: [],
            jsFiles: [],
            imageFiles: [],
            directories: [],
            totalFiles: 0,
            totalSize: 0
        };
        
        this.analysisStartTime = null;
        this.currentProgress = 0;
        this.totalSteps = 0;
        this.autofixPro = new AutoFixPro();
        this.docBuilder = new DocBuilder();
        this.previewSnapshot = new PreviewSnapshot();
        this.aiAssistant = new AIAssistant();
        this.reviewerIntelligence = new ReviewerIntelligence();
        this.liveReviewer = new LiveReviewer();
        this.historyProgress = new HistoryProgress();
    }

    // Méthode principale d\'analyse
    async analyzeTemplate(file) {
        this.analysisStartTime = Date.now();
        this.resetResults();
        
        try {
            this.updateProgress(0, \

